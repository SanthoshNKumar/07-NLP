from django.apps import AppConfig


class InterfaceConfig(AppConfig):
    name = 'interface'
